from flask import Flask, request, jsonify
import pyodbc

app = Flask(__name__)

def get_connection():
    return pyodbc.connect(
        "DRIVER={SQL Server};"
        "SERVER=(server_name);"
        "DATABASE=Biapp;"
        "Trusted_Connection=yes;"
    )


# SIGNUP API
@app.route('/signup', methods=['POST'])
def signup():

    data = request.json
    name = data['name']
    email = data['email']
    password = data['password']

    conn = get_connection()
    cursor = conn.cursor()

    try:

        cursor.execute(
            "INSERT INTO Users (Name, Email, Password) VALUES (?, ?, ?)",
            (name, email, password)
        )

        conn.commit()

        return jsonify({"message": "User created successfully"})

    except:

        return jsonify({"message": "Email already exists"})


# LOGIN API
@app.route('/login', methods=['POST'])
def login():

    data = request.json
    email = data['email']
    password = data['password']

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM Users WHERE Email=? AND Password=?",
        (email, password)
    )

    user = cursor.fetchone()

    if user:
        return jsonify({"message": "Login successful"})
    else:
        return jsonify({"message": "Invalid credentials"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)